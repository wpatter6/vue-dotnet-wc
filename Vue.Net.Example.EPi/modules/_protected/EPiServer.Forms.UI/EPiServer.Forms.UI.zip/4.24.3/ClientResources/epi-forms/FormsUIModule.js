define("epi-forms/FormsUIModule", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/topic", "dojo/when", "dojo/aspect", // dijit
"dijit/Destroyable", // epi
"epi", "epi/_Module", "epi/routes", "epi/string", "epi/shell/form/formFieldRegistry", "epi-cms/store/CustomQueryEngine", "epi-cms/plugin-area/edit-notifications", "epi-cms/contentediting/FormEditing", "epi-cms/compare/views/AllPropertiesCompareView", "epi-cms/compare/viewmodels/AllPropertiesCompareViewModel", "epi/shell/widget/WidgetFactory", // epi-addons
"epi-forms/ModuleSettings", "epi-forms/widget/ContentTypeService", "./FormElementStatusChangeInterceptor", "./WithPlaceHolderFieldFactory", "epi-forms/RetentionPolicyService", "epi-forms/notification/RetentionPolicyNotification"], function ( // dojo
declare, lang, topic, when, aspect, // dijit
Destroyable, // epi
epi, _Module, routes, string, formFieldRegistry, CustomQueryEngine, EditNotifications, FormEditing, AllPropertiesCompareView, AllPropertiesCompareViewModel, WidgetFactory, // epi-addons
ModuleSettings, ContentTypeService, FormElementStatusChangeInterceptor, PlaceHolderFieldFactory, RetentionPolicyService, RetentionPolicyNotification) {
  // module:
  //      epi-forms/FormsModule
  // summary:
  //      EPiServer Form main
  // tags:
  //      public
  return declare([_Module, Destroyable], {
    _settings: null,
    _aspectHandle: null,
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    constructor: function constructor(
    /*Object*/
    settings) {
      this._settings = settings;
    },
    initialize: function initialize() {
      // summary:
      //      Initialize module
      // tags:
      //      public, extensions
      this.inherited(arguments);
      declare.safeMixin(ModuleSettings, this._settings);
      var registry = this.resolveDependency("epi.storeregistry");
      registry.create("epi-forms.formselement", this._getRestPath("formselement"), {
        queryEngine: CustomQueryEngine
      });
      registry.create("epi-forms.formsdata", this._getRestPath("formsdata"), {
        idProperty: "systemcolumn_SubmissionId"
      });
      registry.create("epi-forms.externalfeed", this._getRestPath("externalfeed"));
      registry.create("epi-forms.visitordatasource", this._getRestPath("visitordatasource"));
      registry.create("epi-forms.retentionpolicy", this._getRestPath("retentionpolicy"));
      this.registerDependency("epi.cms.ContentTypeService", new ContentTypeService());
      this._formElementInterceptor = new FormElementStatusChangeInterceptor(); // Setup the Retention Policy service

      this.registerDependency("epi-forms.retentionpolicyservice", new RetentionPolicyService());
      var notification = new RetentionPolicyNotification();
      this.registerDependency("epi-forms.retentionpolicynotification", notification);
      var placeHolderFieldFactory = new PlaceHolderFieldFactory();
      formFieldRegistry.add(placeHolderFieldFactory.createFactory());
      var validatorMessagesPropertyName = "validatorMessages",
          validatorPropertyName = "validators"; // ===========================================HACK===========================================================================================
      // We store custom validator message in a separate property but allow edit that property directly from validator edior.
      // So that the validator editor could update 2 properties: validator and validatorMessages.
      // Below code make sure the validatorMessages property update with the UI (All properties view and Compare view).
      // Add the constructor function to build retention policy notification

      EditNotifications.add(notification);
      aspect.after(FormEditing.prototype, "onPreviewReady", lang.hitch(this, function (viewModel, doc, forceSetup) {
        var vm = viewModel;
        this._defaultWidgetInstantiatorAspectHandle && this._defaultWidgetInstantiatorAspectHandle.remove();
        this._setModelPropertyAspectHandle && this._setModelPropertyAspectHandle.remove();
        vm.raiseCustomValidationMessageChangeEvent = true;
        this._setModelPropertyAspectHandle = aspect.around(vm, "_setModelProperty", function (originalMethod) {
          return function (propertyName, value, oldValue) {
            var result = originalMethod.apply(vm, [propertyName, value, oldValue]);

            if (propertyName === validatorMessagesPropertyName && vm.raiseCustomValidationMessageChangeEvent === true) {
              topic.publish("/epi/forms/validationmessages/update", value);
            }

            return result;
          };
        }); // Inject the AllProperties viewmodel into a ValidatorEditor instance at the time it is created

        this._defaultWidgetInstantiatorAspectHandle = aspect.around(WidgetFactory.prototype, "defaultWidgetInstantiator", function (originalMethod) {
          return function (componentDefinition) {
            if (componentDefinition && componentDefinition.widgetType.toLowerCase() === "epi-forms/contentediting/editors/validatoreditor") {
              declare.safeMixin(componentDefinition.settings, {
                formEditingViewModel: vm,
                canEditCustomMessage: vm.canChangeContent()
              });
            }

            return originalMethod(componentDefinition);
          };
        });
      }), true);

      var isValidatorOrValidatorMessagesPropertyName = function isValidatorOrValidatorMessagesPropertyName(propertyName) {
        if (!propertyName) {
          return false;
        }

        var name = propertyName.toLocaleLowerCase();
        return name === validatorMessagesPropertyName.toLocaleLowerCase() || name === validatorPropertyName.toLocaleLowerCase();
      };

      aspect.around(AllPropertiesCompareViewModel.prototype, "_addPropertyToComparison", function (originalMethod) {
        return function (comparison, property, groupName, prefix) {
          var result = originalMethod.apply(this, [comparison, property, groupName, prefix]);

          if (!isValidatorOrValidatorMessagesPropertyName(property.name)) {
            return result;
          }

          var propertyName = string.pascalToCamel((prefix || "") + validatorMessagesPropertyName),
              leftValue = lang.getObject(propertyName, false, this.leftPropertyMap),
              rightValue = lang.getObject(propertyName, false, this.rightPropertyMap);

          if (!epi.areEqual(leftValue, rightValue)) {
            comparison[groupName.toLowerCase()].indexOf(validatorPropertyName) < 0 && comparison[groupName.toLowerCase()].push(validatorPropertyName);
          }

          return result;
        };
      });
      aspect.around(AllPropertiesCompareViewModel.prototype, "copy", function (originalMethod) {
        return function (propertyName) {
          // "this" is now the current AllPropertiesCompareViewModel object
          if (propertyName.toLocaleLowerCase() === validatorPropertyName.toLocaleLowerCase()) {
            var leftValue = lang.getObject(propertyName, false, this.leftPropertyMap),
                rightValue = lang.getObject(propertyName, false, this.rightPropertyMap);

            if (!epi.areEqual(leftValue, rightValue)) {
              originalMethod.apply(this, [propertyName]);
            } // also copy validator messages


            return originalMethod.apply(this, [validatorMessagesPropertyName]);
          }

          return originalMethod.apply(this, [propertyName]);
        };
      });
      aspect.around(AllPropertiesCompareViewModel.prototype, "_onPropertySaved", function (originalMethod) {
        return function (propertyName, value) {
          // "this" is now the current AllPropertiesCompareViewModel object
          var result = originalMethod.apply(this, [propertyName, value]);

          if (!isValidatorOrValidatorMessagesPropertyName(propertyName)) {
            return result;
          }

          propertyName = validatorMessagesPropertyName;
          var comparison = this.get("comparison");
          var groupName = "information";
          var rightValue = lang.getObject(propertyName, false, this.rightPropertyMap);
          var group = comparison[groupName],
              name = validatorPropertyName.toLowerCase(),
              index = group.indexOf(name),
              areEqual = epi.areEqual(value, rightValue);

          if (index >= 0 && areEqual) {
            group.splice(index, 1);
          } else if (index < 0 && !areEqual) {
            group.splice(0, 0, name);
          }

          this.set("comparison", comparison);
        };
      }); // ==========================================================================================================================================
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _getRestPath: function _getRestPath(
    /*String*/
    name) {
      // summary:
      //      Get EPiServer Forms REST path
      // name: [String]
      //      The current store name
      // tags:
      //      private
      return routes.getRestPath({
        moduleArea: "EPiServer.Forms.UI",
        storeName: name
      });
    }
  });
});